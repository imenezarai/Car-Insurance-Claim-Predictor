import pandas as pd
import joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / 'car_insurance.csv'
EXPORT_PATH = BASE_DIR / 'model_bundle.joblib'


def main():
    df = pd.read_csv(DATA_PATH)

    if 'id' in df.columns:
        df = df.drop(columns=['id'])

    for col in df.select_dtypes(include=['number']).columns:
        df[col] = df[col].fillna(df[col].median())

    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].fillna(df[col].mode()[0])

    X_raw = df.drop(columns=['outcome'])
    y = df['outcome']
    X = pd.get_dummies(X_raw, drop_first=True)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = LogisticRegression(max_iter=2000)
    model.fit(X_train_scaled, y_train)

    y_pred = model.predict(X_test_scaled)
    y_prob = model.predict_proba(X_test_scaled)[:, 1]

    print(f'Accuracy: {accuracy_score(y_test, y_pred):.4f}')
    print(f'ROC AUC: {roc_auc_score(y_test, y_prob):.4f}')

    bundle = {
        'model': model,
        'scaler': scaler,
        'feature_names': X.columns.tolist()
    }
    joblib.dump(bundle, EXPORT_PATH)
    print(f'Model exported to: {EXPORT_PATH}')


if __name__ == '__main__':
    main()
