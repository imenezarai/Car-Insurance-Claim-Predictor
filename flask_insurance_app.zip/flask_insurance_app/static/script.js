const form = document.getElementById('predictionForm');
const resultBox = document.getElementById('result');
const errorBox = document.getElementById('errorBox');
const predictionText = document.getElementById('predictionText');
const probabilityText = document.getElementById('probabilityText');
const segmentText = document.getElementById('segmentText');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    resultBox.classList.add('hidden');
    errorBox.classList.add('hidden');
    errorBox.textContent = '';

    const formData = new FormData(form);

    try {
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Prediction failed.');
        }

        predictionText.textContent = data.prediction === 1 ? 'Claim likely' : 'No claim likely';
        probabilityText.textContent = `${data.probability}%`;
        segmentText.textContent = data.risk_segment;
        resultBox.classList.remove('hidden');
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.classList.remove('hidden');
    }
});
