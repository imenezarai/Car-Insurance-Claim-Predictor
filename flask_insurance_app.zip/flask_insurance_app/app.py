from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
from pathlib import Path

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / 'model_bundle.joblib'

bundle = joblib.load(MODEL_PATH)
model = bundle['model']
scaler = bundle['scaler']
feature_names = bundle['feature_names']


def preprocess_input(form_data: dict) -> pd.DataFrame:
    raw_df = pd.DataFrame([form_data])
    encoded_df = pd.get_dummies(raw_df, drop_first=True)
    encoded_df = encoded_df.reindex(columns=feature_names, fill_value=0)
    scaled = scaler.transform(encoded_df)
    return scaled


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    try:
        payload = {
            'age': int(request.form['age']),
            'gender': int(request.form['gender']),
            'driving_experience': request.form['driving_experience'],
            'education': request.form['education'],
            'income': request.form['income'],
            'credit_score': float(request.form['credit_score']),
            'vehicle_ownership': float(request.form['vehicle_ownership']),
            'vehicle_year': request.form['vehicle_year'],
            'married': float(request.form['married']),
            'children': int(request.form['children']),
            'postal_code': int(request.form['postal_code']),
            'annual_mileage': int(request.form['annual_mileage']),
            'vehicle_type': request.form['vehicle_type'],
            'speeding_violations': int(request.form['speeding_violations']),
            'duis': int(request.form['duis']),
            'past_accidents': int(request.form['past_accidents']),
        }

        scaled_input = preprocess_input(payload)
        prediction = int(model.predict(scaled_input)[0])
        probability = float(model.predict_proba(scaled_input)[0, 1])

        risk_segment = (
            'Very low' if probability < 0.20 else
            'Low' if probability < 0.40 else
            'Moderate' if probability < 0.60 else
            'High' if probability < 0.80 else
            'Very high'
        )

        return jsonify({
            'prediction': prediction,
            'probability': round(probability * 100, 2),
            'risk_segment': risk_segment
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400


if __name__ == '__main__':
    app.run(debug=True)
